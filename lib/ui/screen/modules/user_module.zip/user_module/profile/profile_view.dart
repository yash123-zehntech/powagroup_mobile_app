// import 'dart:io';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:stacked/stacked.dart';
// import 'package:thc_app/common_widget/custom_app_bar_widget.dart';
// import 'package:thc_app/custom_fonts/custom_icons_icons.dart';
// import 'package:thc_app/gen/colors.gen.dart';
// import 'package:thc_app/gen/fonts.gen.dart';
// import 'package:thc_app/services/models/user_profile_resp.dart';
// import 'package:thc_app/ui/screen/modules/user_module/profile/profile_view_model.dart';
// import 'package:thc_app/util/constant.dart';
// import 'package:thc_app/util/util.dart';

// // ignore: must_be_immutable
// class ProfileView extends StatelessWidget {
//   UserProfile? userProfile;
//   ProfileView({Key? key, this.userProfile}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return ViewModelBuilder<ProfileViewModel>.reactive(
//         onModelReady: (viewModel) {
//           viewModel.nameCtrl.text = userProfile?.fullName ?? "";
//         },
//         viewModelBuilder: () => ProfileViewModel(),
//         builder: (context, viewModel, child) => Scaffold(
//             backgroundColor: ColorName.white,
//             body: Column(
//               mainAxisAlignment: MainAxisAlignment.start,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               mainAxisSize: MainAxisSize.max,
//               children: [
//                 SizedBox(
//                   width: ScreenUtil().screenWidth,
//                   height: ScreenUtil().statusBarHeight,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     SizedBox(
//                       width: 10,
//                     ),
//                     IconButton(
//                       onPressed: () => viewModel.navigationService.back(),
//                       icon: const Icon(
//                         Icons.arrow_back_ios,
//                         color: Colors.black,
//                         size: 30,
//                       ),
//                     ),
//                     Expanded(child: Container()),
//                     Container(
//                       height: 250.h,
//                       width: 150.w,
//                       decoration: const BoxDecoration(
//                           color: ColorName.greyBgcolor,
//                           borderRadius: BorderRadius.only(
//                             bottomLeft: Radius.circular(100),
//                             bottomRight: Radius.circular(100),
//                           )),
//                       child: Stack(
//                         children: [
//                           Align(
//                             alignment: Alignment.bottomCenter,
//                             child: Container(
//                               margin: const EdgeInsets.all(15),
//                               height: 120.w,
//                               width: 120.w,
//                               decoration: const BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: ColorName.white,
//                               ),
//                               child: ClipRRect(
//                                 borderRadius: BorderRadius.circular(100),
//                                 child: viewModel.xImageFile != null
//                                     ? Image.file(
//                                         File(viewModel.xImageFile!.path),
//                                         fit: BoxFit.fill,
//                                       )
//                                     : CachedNetworkImage(
//                                         imageUrl:
//                                             userProfile?.profileImageUrl ?? "",
//                                         fit: BoxFit.fill,
//                                         placeholder: (context, url) => Padding(
//                                           padding: const EdgeInsets.all(8.0),
//                                           child: Padding(
//                                             padding: const EdgeInsets.all(20.0),
//                                             child: CircularProgressIndicator(),
//                                           ),
//                                         ),
//                                         errorWidget: (context, url, error) =>
//                                             Container(
//                                           height: 120.w,
//                                           width: 120.w,
//                                           decoration: BoxDecoration(
//                                               border: Border.all(
//                                                   color:
//                                                       ColorName.greyUltraLite),
//                                               shape: BoxShape.circle,
//                                               color: ColorName.greyBgcolor),
//                                           child: Icon(
//                                             Icons.person,
//                                             size: 80.w,
//                                             color: ColorName.greyUltraLite,
//                                           ),
//                                         ),
//                                       ),
//                               ),
//                             ),
//                           ),
//                           viewModel.editable
//                               ? Positioned(
//                                   bottom: 20,
//                                   right: 20,
//                                   child: Container(
//                                     height: 35.w,
//                                     width: 35.w,
//                                     decoration: const BoxDecoration(
//                                         color: ColorName.white,
//                                         shape: BoxShape.circle),
//                                     child: Center(
//                                       child: InkWell(
//                                         child: const Icon(
//                                           CustomIcons.camera,
//                                           color: ColorName.yello,
//                                         ),
//                                         onTap: () {
//                                           imageSelectionOption(
//                                               viewModel, context);
//                                         },
//                                       ),
//                                     ),
//                                   ),
//                                 )
//                               : SizedBox()
//                         ],
//                       ),
//                     ),
//                     Expanded(child: Container()),
//                     IconButton(
//                         onPressed: () {
//                           viewModel.onEditIconClick();
//                         },
//                         icon: viewModel.editable
//                             ? Icon(
//                                 Icons.edit_off,
//                               )
//                             : Icon(Icons.edit, color: ColorName.greyUltraLite)),
//                     SizedBox(
//                       width: 10,
//                     ),
//                   ],
//                 ),

//                 // CustomappBar(
//                 //   backColor: ColorName.greyBgcolor,
//                 //   leading: IconButton(
//                 //     onPressed: () => viewModel.navigationService.back(),
//                 //     icon: const Icon(
//                 //       Icons.arrow_back_ios,
//                 //       color: Colors.black,
//                 //       size: 30,
//                 //     ),
//                 //   ),
//                 //   trailing: IconButton(
//                 //       onPressed: () {
//                 //         viewModel.onEditIconClick();
//                 //       },
//                 //       icon: viewModel.editable
//                 //           ? Icon(
//                 //               Icons.edit_off,
//                 //             )
//                 //           : Icon(Icons.edit, color: ColorName.greyUltraLite)),
//                 // ),
//                 Expanded(
//                   child: ListView(
//                     physics: BouncingScrollPhysics(),
//                     children: [
//                       Column(
//                         children: [
//                           const SizedBox(
//                             height: 15,
//                           ),
//                           Row(
//                             children: [
//                               SizedBox(
//                                 width: 30,
//                               ),
//                               Expanded(
//                                 child: TextField(
//                                   enabled: viewModel.editable,
//                                   controller: viewModel.nameCtrl,
//                                   focusNode: viewModel.nameNode,
//                                   textAlign: TextAlign.center,
//                                   style: TextStyle(
//                                       color: ColorName.blackText,
//                                       fontSize: 34.sp,
//                                       fontFamily: FontFamily.babas),
//                                   decoration: InputDecoration(
//                                       hintText: Constants.fullName,
//                                       hintStyle: TextStyle(
//                                         color: ColorName.blackliteText,
//                                         fontSize: 16.sp,
//                                       ),
//                                       border: viewModel.editable
//                                           ? UnderlineInputBorder(
//                                               borderSide: BorderSide(
//                                                   color: Colors.black,
//                                                   width: 30),
//                                             )
//                                           : InputBorder.none),
//                                 ),
//                               ),
//                               SizedBox(
//                                 width: 30,
//                               ),
//                             ],
//                           ),
//                           // Text(
//                           //   "${userProfile!.fullName ?? "__"}",
//                           //   style: TextStyle(
//                           //       color: ColorName.blackText,
//                           //       fontSize: 34.sp,
//                           //       fontFamily: FontFamily.babas),
//                           // ),
//                           const SizedBox(
//                             height: 3,
//                           ),
//                           Text(
//                             userProfile!.countryCode! +
//                                 userProfile!.mobileNumber.toString(),
//                             style: TextStyle(
//                                 color: ColorName.blackliteText,
//                                 fontSize: 17.sp,
//                                 fontFamily: FontFamily.ubuntu),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//                 viewModel.editable
//                     ? Align(
//                         alignment: Alignment.bottomCenter,
//                         child: viewModel.isBusy
//                             ? AppUtil.showProgress()
//                             : InkWell(
//                                 onTap: () {
//                                   viewModel.onUpdateClick();
//                                 },
//                                 child: Container(
//                                   width: ScreenUtil().screenWidth,
//                                   height: 65.h,
//                                   margin: EdgeInsets.only(left: 30, right: 30),
//                                   decoration: BoxDecoration(
//                                       color: ColorName.buttonColor,
//                                       borderRadius:
//                                           BorderRadius.circular(4.sp)),
//                                   padding: EdgeInsets.only(
//                                       top: 10.sp, bottom: 10.sp),
//                                   child: Center(
//                                     child: Text(
//                                       Constants.update,
//                                       style: TextStyle(
//                                           color: ColorName.white,
//                                           fontWeight: FontWeight.bold,
//                                           fontSize: 20.sp),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                       )
//                     : SizedBox(),
//                 SizedBox(
//                   height: 10,
//                 ),
//               ],
//             )));
//   }

//   // camera or gallary option
//   imageSelectionOption(ProfileViewModel viewModel, BuildContext context) {
//     return showModalBottomSheet(
//       backgroundColor: Colors.transparent,
//       context: context,
//       builder: (context) {
//         return Container(
//           margin: EdgeInsets.all(10),
//           padding: EdgeInsets.all(7),
//           height: 180,
//           width: ScreenUtil().screenWidth,
//           decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(10),
//               border: Border.all(color: Colors.black)),
//           child: Column(
//             children: [
//               SizedBox(
//                 height: 20,
//               ),
//               Text(
//                 Constants.select_from.toUpperCase(),
//                 style: TextStyle(
//                     color: ColorName.yello,
//                     fontWeight: FontWeight.bold,
//                     fontSize: 18.sp),
//               ),
//               SizedBox(
//                 height: 20,
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   Column(
//                     children: [
//                       Container(
//                         padding: const EdgeInsets.all(07),
//                         decoration: BoxDecoration(
//                           color: ColorName.yello,
//                           borderRadius: BorderRadius.circular(100),
//                         ),
//                         child: IconButton(
//                           onPressed: () {
//                             viewModel.getImage(1);
//                           },
//                           icon: Icon(Icons.camera_alt_outlined,
//                               color: Colors.white),
//                         ),
//                       ),
//                       Text(
//                         Constants.camera,
//                         style: TextStyle(
//                             color: ColorName.yello,
//                             fontSize: 16.sp,
//                             fontWeight: FontWeight.bold),
//                       ),
//                     ],
//                   ),
//                   Column(
//                     children: [
//                       Container(
//                         padding: const EdgeInsets.all(07),
//                         decoration: BoxDecoration(
//                           color: ColorName.yello,
//                           borderRadius: BorderRadius.circular(100),
//                         ),
//                         child: IconButton(
//                           onPressed: () {
//                             viewModel.getImage(2);
//                           },
//                           icon: Icon(Icons.file_copy_outlined,
//                               color: Colors.white),
//                         ),
//                       ),
//                       Text(
//                         Constants.gallery,
//                         style: TextStyle(
//                             color: ColorName.yello,
//                             fontSize: 16.sp,
//                             fontWeight: FontWeight.bold),
//                       ),
//                     ],
//                   )
//                 ],
//               )
//             ],
//           ),
//         );
//       },
//     );
//   }
// }
