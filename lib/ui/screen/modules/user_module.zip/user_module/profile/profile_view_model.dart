// import 'dart:io';

// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:stacked/stacked.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:stacked_services/stacked_services.dart';
// import 'package:thc_app/app/locator.dart';
// import 'package:thc_app/services/api.dart';
// import 'package:thc_app/services/models/prifile_update_resp.dart';
// import 'package:thc_app/util/constant.dart';
// import 'package:thc_app/util/shared_preference.dart';
// import 'package:thc_app/util/util.dart';

// class ProfileViewModel extends BaseViewModel {
//   final navigationService = locator<NavigationService>();
//   final bottomSheetService = locator<BottomSheetService>();
//   final Api api = locator<Api>();
//   final ImagePicker _picker = ImagePicker();
//   XFile? _xImageFile;

//   XFile? get xImageFile => _xImageFile;

//   set xImageFile(XFile? xImageFile) {
//     _xImageFile = xImageFile;
//     notifyListeners();
//   }

//   File? _selectedFile;
//   final nameCtrl = TextEditingController();
//   final nameNode = FocusNode();
//   bool _editable = false;

//   bool get editable => _editable;

//   set editable(bool editable) {
//     _editable = editable;
//     notifyListeners();
//   }

//   File? get selectedFile => _selectedFile;

//   set selectedFile(File? selectedFile) {
//     _selectedFile = selectedFile;
//     notifyListeners();
//   }

//   // select profile image from camera or gallery
//   getImage(int option) async {
//     navigationService.back();
//     try {
//       if (option == 1) {
//         xImageFile = await _picker.pickImage(source: ImageSource.camera);
//       } else {
//         xImageFile = await _picker.pickImage(source: ImageSource.gallery);
//       }
//       selectedFile = File(xImageFile!.path);
//     } catch (e) {
//       print(e);
//     }
//   }

//   uploadvideo(
//     String title,
//     String imagePath,
//   ) async {
//     Map<String, String> assetsUpload = {};
//     setBusy(true);
//     assetsUpload["full_name"] = nameCtrl.text;
//     UpdateProfileResp updateProfileResp = await api.updateUserProfile(
//         assetsUpload,
//         await SharedPre.getStringValue(SharedPre.accessToken),
//         imagePath);
//     notifyListeners();
//     setBusy(false);
//     switch (updateProfileResp.statusCode ?? 0) {
//       case Constants.sucessCode:
//         editable = false;
//         if (updateProfileResp.userFullName != null &&
//             updateProfileResp.userFullName!.isNotEmpty) {
//           SharedPre.setStringValue(
//               SharedPre.NAME, updateProfileResp.userFullName!);
//         }

//         if (updateProfileResp.profileImageUrl != null &&
//             updateProfileResp.profileImageUrl!.isNotEmpty) {
//           await CachedNetworkImage.evictFromCache(
//               updateProfileResp.profileImageUrl!);
//           SharedPre.setStringValue(
//               SharedPre.profileImage, updateProfileResp.profileImageUrl!);
//         }

//         AppUtil.showToast(Constants.updatedSuccessfully);
//         break;
//       case Constants.errorCode:
//         AppUtil.showToast(updateProfileResp.error ?? '');
//         break;
//       case Constants.networkErroCode:
//         AppUtil.showToast(updateProfileResp.error ?? '');
//         break;
//       default:
//         AppUtil.showToast(
//             updateProfileResp.message ?? updateProfileResp.error ?? '');
//         break;
//     }
//   }

// // on update buttion click
//   onUpdateClick() {
//     if (nameCtrl.text.isNotEmpty) {
//       uploadvideo(nameCtrl.text, selectedFile?.path ?? "");
//     } else {
//       AppUtil.showToast(Constants.nameCannotEmpty);
//     }
//   }

//   // on edit icon click
//   void onEditIconClick() {
//     editable = !editable;
//     if (editable) {
//       nameNode.requestFocus();
//       notifyListeners();
//     }
//   }
// }
