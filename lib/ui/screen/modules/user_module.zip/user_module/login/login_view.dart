import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:powagroup1/custom_fonts/powa_group_icon_icons.dart';
import 'package:powagroup1/ui/screen/modules/user_module/login/login_view_model.dart';
import 'package:powagroup1/ui/screen/modules/user_module/register/register_view.dart';
import 'package:powagroup1/util/util.dart';
import 'package:powagroup1/util/validator.dart';
import 'package:stacked/stacked.dart';

class LoginView extends StatelessWidget {
  const LoginView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/icon/blur.png'), fit: BoxFit.fill),
          )),
      Scaffold(
        backgroundColor: Colors.transparent,
        bottomNavigationBar: endContent(context),
        body: ViewModelBuilder<LoginViewMode>.reactive(
            viewModelBuilder: () => LoginViewMode(),
            onModelReady: (viewModel) => {},
            builder: (context, viewModel, child) => Scaffold(
                backgroundColor: Colors.transparent,
                body: Padding(
                  padding: EdgeInsets.only(
                      left: AppUtil.displayWidth(context) * 0.04,
                      right: AppUtil.displayWidth(context) * 0.04),
                  child: ListView(
                    physics: NeverScrollableScrollPhysics(),
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(
                            top: AppUtil.displayWidth(context) * 0.10.h),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            loginContent(),
                            Padding(
                              padding: EdgeInsets.only(top: 8.h),
                              child: loginSubContent(),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: AppUtil.displayWidth(context) * 0.09.h),
                        child: Container(
                          height: MediaQuery.of(context).size.height / 1.9,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              color: Color(0XFFFFFFFF),
                              borderRadius: BorderRadius.circular(15.0.r)),
                          child: Stack(
                            children: [
                              ListView(
                                physics: NeverScrollableScrollPhysics(),
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                      // top: AppUtil.displayHeight(context) *
                                      //     0.01.h,
                                      left: AppUtil.displayHeight(context) *
                                          0.02.h,
                                      right: AppUtil.displayHeight(context) *
                                          0.02.h,
                                    ),
                                    child: getLoginForm(context, viewModel),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        top: 10.h,
                                        right: AppUtil.displayHeight(context) *
                                            0.06.h),
                                    child: forgetPasswordContainer(),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(
                                        top: 25.h, bottom: 20.h),
                                    child: LoginButton(context, viewModel),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ))),
      ),
    ]);
  }

  Widget forgetPasswordContainer() => Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.end,
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          TextButton(
            onPressed: () {},
            child: Text(
              "ForgetPassword ?",
              textAlign: TextAlign.end,
              style: TextStyle(
                  fontFamily: 'Raleway',
                  fontSize: 11.0.sp,
                  fontWeight: FontWeight.w400,
                  color: Color(0xff36393C)),
            ),
          ),
        ],
      );

  Widget getLoginForm(context, LoginViewMode viewModel) => Form(
        key: viewModel.formKey,
        child: Padding(
          padding: EdgeInsets.only(
              left: AppUtil.displayWidth(context) * 0.01.h,
              right: AppUtil.displayWidth(context) * 0.01.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                  child: Padding(
                padding: EdgeInsets.only(
                  top: AppUtil.displayHeight(context) * 0.06.h,
                ),
                child: emailContent(),
              )),
              TextFormField(
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
                keyboardType: TextInputType.emailAddress,
                controller: viewModel.userNameController,
                validator: (value) => Validation.emailValidate(value),
                style: TextStyle(
                    color: ColorName.blackText,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Raleway',
                    fontSize: 14.sp),
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 10.sp, vertical: 15.sp),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: Color(0xFFD60505),
                  )),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: const BorderSide(
                      color: ColorName.hintColor,
                    ),
                  ),
                  hintStyle: new TextStyle(
                      color: ColorName.hintColor,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'Raleway',
                      fontSize: 10.0.sp),
                  hintText: "Enter Email",
                  suffixIcon: Icon(PowaGroupIcon.email, size: 24.h),
                ),
                onSaved: (value) => viewModel.userName = value,
              ),
              SizedBox(
                height: 20.h,
              ),
              Container(child: passwordContent()),
              TextFormField(
                textInputAction: TextInputAction.next,
                onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
                //onFieldSubmitted: _handleSubmitted,
                validator: (value) =>
                    value.isEmpty ? "Password is required" : null,
                controller: viewModel.passwordController,
                style: TextStyle(
                    color: ColorName.blackText,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Raleway',
                    fontSize: 10.0.sp),
                obscureText: viewModel.passwordVisible,
                decoration: InputDecoration(
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 10.sp, vertical: 15.sp),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0xFFD60505),
                    ),
                    //borderRadius: BorderRadius.circular(5),
                  ),
                  hintStyle: new TextStyle(
                      color: ColorName.hintColor,
                      fontWeight: FontWeight.w400,
                      fontSize: 10.0.sp),
                  hintText: "Enter Password",
                  suffixIcon: IconButton(
                    icon: Icon(
                      !viewModel.passwordVisible
                          ? Icons.remove_red_eye
                          : Icons.visibility_off_outlined,
                      size: 24.h,
                    ),
                    onPressed: () {
                      viewModel.passwordVisible = !viewModel.passwordVisible;
                    },
                  ),
                ),
                onSaved: (value) => viewModel.password = value,
              ),
            ],
          ),
        ),
      );

  Widget loginContent() => Container(
        child: Text('Login Account',
            style: TextStyle(
                color: ColorName.blackText,
                fontFamily: 'Raleway-Black',
                fontWeight: FontWeight.w800,
                fontSize: 30.0.sp)),
      );
  Widget loginSubContent() => Container(
        child: Text('Hello, welcome back to our account !',
            style: TextStyle(
                color: Color(0xff36393C),
                fontFamily: 'Raleway',
                fontWeight: FontWeight.w400,
                fontSize: 11.0.sp)),
      );
  Widget emailContent() => Container(
        child: Text("Email I'd",
            style: TextStyle(
                color: Color(0xff36393C),
                fontFamily: 'Raleway',
                fontWeight: FontWeight.w500,
                fontSize: 10.0.sp)),
      );
  Widget passwordContent() => Container(
        child: Text('Password',
            style: TextStyle(
                color: Color(0xff36393C),
                fontFamily: 'Raleway',
                fontWeight: FontWeight.w500,
                fontSize: 10.0.sp)),
      );

  Widget endContent(context) => Padding(
        padding: EdgeInsets.only(bottom: 10.0.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            RichText(
              text: TextSpan(
                  text: "Not register yet ?",
                  style: TextStyle(
                      color: Color(0xff1B1D1E),
                      fontSize: 11.sp,
                      fontFamily: 'Raleway',
                      fontWeight: FontWeight.w400),
                  children: <TextSpan>[
                    TextSpan(
                      recognizer: new TapGestureRecognizer()
                        ..onTap = () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => RegisterView()),
                            ),
                      text: ' Create Account',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 12.sp,
                          fontFamily: 'Raleway',
                          color: Color(0xFFD60505)),
                    )
                  ]),
            ),
          ],
        ),
      );

  Widget LoginButton(context, LoginViewMode viewModel) => Padding(
        padding: EdgeInsets.only(
            right: AppUtil.displayWidth(context) * 0.07.h,
            left: AppUtil.displayWidth(context) * 0.07.h),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: viewModel.isBusy
              ? AppUtil.showProgress()
              : InkWell(
                  onTap: () {
                    if (viewModel.formKey.currentState.validate()) {
                      viewModel.formKey.currentState.save();
                      viewModel.onLoginButtonClick();
                    }
                  },
                  child: Container(
                    height: 58.h,
                    width: MediaQuery.of(context).size.width,
                    child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xffD60505),

                              // blurRadius: 3.0.r,
                            ),
                          ],
                          borderRadius: BorderRadius.circular(10.r),
                          // gradient: LinearGradient(
                          //     stops: [0.1, 1],
                          //     begin: Alignment.topLeft,
                          //     end: Alignment.bottomRight,
                          //     colors: [
                          //       Color(0xffD60505),
                          //       Color.fromARGB(222, 179, 175, 1)
                          //     ])
                        ),
                        padding: EdgeInsets.only(right: 3.r, left: 17.h),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Text(
                                  "Log In",
                                  style: TextStyle(
                                      color: ColorName.white,
                                      fontSize: 14.0.sp,
                                      fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                          ],
                        )),
                  ),
                ),
        ),
      );
}
