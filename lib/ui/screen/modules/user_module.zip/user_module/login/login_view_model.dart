import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:powagroup1/app/locator.dart';
import 'package:powagroup1/services/api.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class LoginViewMode extends BaseViewModel {
  final navigationService = locator<NavigationService>();
  TextEditingController userNameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  GlobalKey<FormState> formKey = new GlobalKey<FormState>();
  String _username = '';
  String _password = '';
  bool _passwordVisible = false;
  bool value = false;

  Api api = locator<Api>();

  String get userName => _username;
  set userName(String userName) {
    _username = userName;
    notifyListeners();
  }

  String get password => _password;
  set password(String password) {
    _password = password;
    notifyListeners();
  }

  bool get passwordVisible => _passwordVisible;
  set passwordVisible(bool passwordVisible) {
    _passwordVisible = passwordVisible;
    notifyListeners();
  }

  // on login buttion clik
  onLoginButtonClick() {
    if (userNameController.text.isNotEmpty) {
      callSendOtpApi();
    }
  }

  //  send otp api calling
  callSendOtpApi() async {
    // setBusy(true);
    // Map<String, dynamic> request = {};
    // request["country_code"] = countryCode;
    // request["mobile_number"] = int.parse(numberctrl.text);
    // SendOtpResp loginResp = await api.sendOtpApi(request);
    // switch (loginResp.statusCode) {
    //   case Constants.sucessCode:
    //     OtpviewArguments arg =
    //         OtpviewArguments(number: numberctrl.text, countryCode: countryCode);
    //     navigationService.navigateTo(Routes.otpview, arguments: arg);

    //     // SharedPre.setStringValue(SharedPre.PHONE_NUMBER, emailCtrl.text);
    //     // SharedPre.setStringValue(
    //     //  SharedPre.COUNTRY_CODE, "+" + country.phoneCode);
    //     break;
    //   case Constants.wrongError:
    //     //COMMENT
    //     // OtpviewArguments arg =
    //     //     OtpviewArguments(number: numberctrl.text, countryCode: countryCode);
    //     // navigationService.navigateTo(Routes.otpview, arguments: arg);
    //     //  //COMMENT
    //     AppUtil.showToast(loginResp.error ?? '');
    //     // AppUtil.showToast(loginResp.message ?? '');
    //     break;
    //   case Constants.networkErroCode:
    //     AppUtil.showToast(loginResp.error ?? '');
    //     break;
    //   default:
    //     {
    //       if (loginResp.error != null && loginResp.error!.isNotEmpty) {
    //         AppUtil.showToast(loginResp.error ?? '');
    //       } else if (loginResp.message != null &&
    //           loginResp.message!.isNotEmpty) {
    //         AppUtil.showToast(loginResp.message ?? '');
    //       }
    //     }
    //     break;
    // }
    // setBusy(false);
  }
}
