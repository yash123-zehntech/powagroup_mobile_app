import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:powagroup1/custom_fonts/powa_group_icon_icons.dart';
import 'package:powagroup1/gen/colors.gen.dart';
import 'package:powagroup1/ui/screen/modules/user_module/register/register_view_model.dart';
import 'package:powagroup1/util/util.dart';
import 'package:powagroup1/util/validator.dart';
import 'package:stacked/stacked.dart';

class RegisterView extends StatelessWidget {
  const RegisterView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/icon/blur.png'), fit: BoxFit.cover),
          )),
      Scaffold(
          backgroundColor: Colors.transparent,
          bottomNavigationBar: endContent(),
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                PowaGroupIcon.group_131934,
                color: Color(0xff36393C),
                size: 25.h,
              ),
            ),
            backgroundColor: Colors.transparent,
            elevation: 0,
          ),
          body: ViewModelBuilder<RegisterViewMode>.reactive(
              viewModelBuilder: () => RegisterViewMode(),
              onModelReady: (viewModel) => {},
              builder: (context, viewModel, child) => Padding(
                    padding: EdgeInsets.only(
                        left: AppUtil.displayWidth(context) * 0.04,
                        right: AppUtil.displayWidth(context) * 0.04),
                    child: Column(
                      // physics: NeverScrollableScrollPhysics(),
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(
                              top: AppUtil.displayWidth(context) * 0.01.h),
                          child: Column(
                            children: [
                              registerContent(),
                              Padding(
                                padding: EdgeInsets.only(top: 8.h),
                                child: registerSubContent(),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              top: AppUtil.displayWidth(context) * 0.1.h),
                          child: Container(
                            height: MediaQuery.of(context).size.height * 2 / 3,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Color(0XFFFFFFFF),
                                borderRadius: BorderRadius.circular(15.0.r)),
                            child: Stack(
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(
                                      bottom: AppUtil.displayHeight(context) *
                                          0.06.h),
                                  child: ListView(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: AppUtil.displayHeight(context) *
                                              0.04.h,
                                          left: AppUtil.displayHeight(context) *
                                              0.02.h,
                                          right:
                                              AppUtil.displayHeight(context) *
                                                  0.03.h,
                                        ),
                                        child:
                                            getRegisterForm(context, viewModel),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(bottom: 10.0.h),
                                  child: submitButton(context, viewModel),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ))),
    ]);
  }

  Widget dropDown(RegisterViewMode viewModel, type, text, list, int value) =>
      Column(
        children: [
          DropdownButton<String>(
            underline: Container(
              height: 1.h,
              width: 1.w,
              color: Colors.grey,
            ),
            hint: value == 1
                ? viewModel.dropDownTrade == null
                    ? Padding(
                        padding: EdgeInsets.only(left: 10.h),
                        child: Text(text),
                      )
                    : Text(
                        viewModel.dropDownTrade,
                        style: TextStyle(color: Colors.grey),
                      )
                : value == 2
                    ? viewModel.dropDownAct == null
                        ? Padding(
                            padding: EdgeInsets.only(left: 10.h),
                            child: Text(text),
                          )
                        : Text(
                            viewModel.dropDownAct,
                            style: TextStyle(color: Colors.grey),
                          )
                    : value == 3
                        ? viewModel.dropDownAccount == null
                            ? Padding(
                                padding: EdgeInsets.only(left: 10.h),
                                child: Text(text),
                              )
                            : Text(
                                viewModel.dropDownAccount,
                                style: TextStyle(color: Colors.grey),
                              )
                        : Container(),
            isExpanded: true,
            iconSize: 30.0.h,
            style: TextStyle(
                color: ColorName.blackText,
                fontWeight: FontWeight.w400,
                fontFamily: 'Raleway',
                fontSize: 14.0.sp),
            items: list.map<DropdownMenuItem<String>>(
              (val) {
                return DropdownMenuItem<String>(
                  value: val,
                  child: Text(
                    val,
                    style: TextStyle(
                        color: ColorName.blackText,
                        fontWeight: FontWeight.w400,
                        fontFamily: 'Raleway',
                        fontSize: 14.0.sp),
                  ),
                );
              },
            ).toList(),
            onChanged: (val) {
              value == 1
                  ? viewModel.dropDownTrade = val
                  : value == 2
                      ? viewModel.dropDownAct = val
                      : value == 3
                          ? viewModel.dropDownAccount = val
                          : Container();

              viewModel.notifyListeners();
            },
          ),
          SizedBox(
            height: 15.h,
          ),
        ],
      );

  Widget formField(labelText, context, hintText, icon, keyboardType, controller,
          validationfield) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(child: fieldContent(labelText)),
          TextFormField(
            textInputAction: TextInputAction.next,
            onFieldSubmitted: (_) => FocusScope.of(context).nextFocus(),
            keyboardType: keyboardType,
            controller: controller,
            validator: (value) => validationfield(value),
            style: TextStyle(
                color: ColorName.blackText,
                fontWeight: FontWeight.w600,
                fontFamily: 'Raleway',
                fontSize: 10.sp),
            decoration: InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 10.sp, vertical: 15.sp),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                color: Color(0xFFD60505),
              )),
              enabledBorder: UnderlineInputBorder(
                borderSide: const BorderSide(
                  color: ColorName.hintColor,
                ),
              ),
              hintStyle: new TextStyle(
                  color: ColorName.hintColor,
                  fontWeight: FontWeight.w400,
                  fontFamily: 'Raleway',
                  fontSize: 10.0.sp),
              hintText: hintText,
              suffixIcon: Icon(icon, size: 24.h),
            ),
            onSaved: (value) => controller = value,
          ),
          SizedBox(
            height: 15.h,
          ),
        ],
      );

  Widget getRegisterForm(context, RegisterViewMode viewModel) => Form(
        key: viewModel.formKey,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <
            Widget>[
          Container(
              child: formField(
                  'Name',
                  context,
                  'Name',
                  PowaGroupIcon.artboard,
                  TextInputType.name,
                  viewModel.userNameController,
                  Validation.fieldEmpty)),
          Container(
              child: formField(
                  'Mobile Number',
                  context,
                  'Mobile Number',
                  PowaGroupIcon.group_19,
                  TextInputType.number,
                  viewModel.mobileNumberController,
                  Validation.validMobile)),
          Container(
              child: formField(
                  'Email Address',
                  context,
                  'Enter Address',
                  PowaGroupIcon.email,
                  TextInputType.emailAddress,
                  viewModel.emailController,
                  Validation.emailValidate)),
          Container(
              child: formField(
                  'Account Name',
                  context,
                  'Name of person',
                  PowaGroupIcon.artboard,
                  TextInputType.name,
                  viewModel.accountNameController,
                  Validation.fieldEmpty)),
          Container(
              child: formField(
                  'Account Email',
                  context,
                  'Enter accounts email address',
                  PowaGroupIcon.email,
                  TextInputType.emailAddress,
                  viewModel.emailController,
                  Validation.emailValidate)),
          Container(
              child: formField(
                  'Account Phone Number',
                  context,
                  'Who do we call re accounts',
                  PowaGroupIcon.group_19,
                  TextInputType.number,
                  viewModel.mobileNumberController,
                  Validation.validMobile)),
          Container(
              child: formField(
                  'Company Name',
                  context,
                  'Please use full legel name',
                  PowaGroupIcon.group_132002,
                  TextInputType.name,
                  viewModel.companyNameController,
                  Validation.fieldEmpty)),
          Container(
              child: formField(
                  'ABN',
                  context,
                  'For new customer applications',
                  PowaGroupIcon.add,
                  TextInputType.name,
                  viewModel.abnController,
                  Validation.fieldEmpty)),
          Container(
              child: formField(
                  'ACN',
                  context,
                  'If Application and have company or trust',
                  PowaGroupIcon.add,
                  TextInputType.name,
                  viewModel.acnController,
                  Validation.fieldEmpty)),
          Container(child: fieldContent('Trade Type select from drop down')),
          SizedBox(
            height: 15.h,
          ),
          Container(
              child: dropDown(viewModel, viewModel.dropDownTrade, 'select',
                  viewModel.trade, 1)),
          Container(
              child: formField(
                  'Business Address',
                  context,
                  'Street number & street name',
                  PowaGroupIcon.add,
                  TextInputType.name,
                  viewModel.businessAddController,
                  Validation.fieldEmpty)),
          Container(
              child: formField(
                  'Post Code',
                  context,
                  'code',
                  PowaGroupIcon.add,
                  TextInputType.name,
                  viewModel.postCodeController,
                  Validation.fieldEmpty)),
          Container(
              child: fieldContent('state/Territory select from drop down')),
          SizedBox(
            height: 15.h,
          ),
          Container(
              child: dropDown(
                  viewModel, viewModel.dropDownAct, 'ACT', viewModel.act, 2)),
          ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 3,
              itemBuilder: (BuildContext context, int index) {
                return Row(
                  children: <Widget>[
                    Checkbox(
                      value: viewModel.CheckboxListItem[index].isSelect,
                      onChanged: (bool value) {
                        viewModel.CheckboxListItem[index].isSelect =
                            !viewModel.CheckboxListItem[index].isSelect;
                        viewModel.notifyListeners();
                      },
                    ),
                    Expanded(
                      child: Text(
                        '${viewModel.CheckboxListItem[index].title}',
                        style: TextStyle(fontSize: 13.0.h),
                      ),
                    ),
                  ], //<Widget>[]
                );
              }),
          Container(child: fieldContent('Select your preferred account type')),
          SizedBox(
            height: 15.h,
          ),
          Container(
              child: dropDown(viewModel, viewModel.dropDownAccount, 'select',
                  viewModel.accountType, 3)),
        ]),
        // ])
      );

  Widget registerContent() => Container(
        child: Text('Create Account',
            style: TextStyle(
                color: ColorName.blackText,
                fontFamily: 'Raleway-Black',
                fontWeight: FontWeight.w800,
                fontSize: 30.0.sp)),
      );
  Widget registerSubContent() => Container(
        child: Text('Please Create Account to Contiune with App',
            style: TextStyle(
                color: Color(0xff36393C),
                fontFamily: 'Raleway',
                fontWeight: FontWeight.w400,
                fontSize: 11.0.sp)),
      );
  Widget fieldContent(text) => Container(
        child: Text(text,
            style: TextStyle(
                color: Color(0xff36393C),
                fontFamily: 'Raleway',
                fontWeight: FontWeight.w500,
                fontSize: 10.0.sp)),
      );

  Widget endContent() => Padding(
        padding: EdgeInsets.only(bottom: 10.0.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
                child: RichText(
              text: TextSpan(
                  text: "Already have an account ?",
                  style: TextStyle(
                      color: Color(0xff1B1D1E),
                      fontSize: 11.sp,
                      fontFamily: 'Raleway',
                      fontWeight: FontWeight.w400),
                  children: <TextSpan>[
                    TextSpan(
                      recognizer: new TapGestureRecognizer()
                        ..onTap = () => print('Tap Here onTap'),
                      text: ' Request for Login',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 12.sp,
                          fontFamily: 'Raleway',
                          color: Color(0xFFD60505)),
                    )
                  ]),
            )),
          ],
        ),
      );

  Widget submitButton(context, RegisterViewMode viewModel) => Padding(
        padding: EdgeInsets.only(
            right: AppUtil.displayWidth(context) * 0.04,
            left: AppUtil.displayWidth(context) * 0.04),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: viewModel.isBusy
              ? AppUtil.showProgress()
              : InkWell(
                  onTap: () {
                    if (viewModel.formKey.currentState.validate()) {
                      viewModel.formKey.currentState.save();
                      viewModel.onRegisterButtonClick();
                    }
                  },
                  child: Container(
                    height: 58.h,
                    width: MediaQuery.of(context).size.width,
                    child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xffD60505),
                              // blurRadius: 7.0.r,
                            ),
                          ],
                          borderRadius: BorderRadius.circular(10.r),
                          // gradient: LinearGradient(
                          //     stops: [0.1, 1],
                          //     begin: Alignment.topLeft,
                          //     end: Alignment.bottomRight,
                          //     colors: [
                          //       Color(0xffD60505),
                          //       Color(0xffD60505)
                          //     ])
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Text(
                                  "Submit",
                                  style: TextStyle(
                                      color: ColorName.white,
                                      fontSize: 14.0.sp,
                                      fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                          ],
                        )),
                  ),
                ),
        ),
      );
}
