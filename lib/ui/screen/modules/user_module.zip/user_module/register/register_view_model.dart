import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:powagroup1/app/locator.dart';
import 'package:powagroup1/services/api.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked_services/stacked_services.dart';

class RegisterViewMode extends BaseViewModel {
  final navigationService = locator<NavigationService>();
  TextEditingController userNameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController accountNameController = TextEditingController();
  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController companyNameController = TextEditingController();
  TextEditingController abnController = TextEditingController();
  TextEditingController acnController = TextEditingController();
  TextEditingController businessAddController = TextEditingController();
  TextEditingController postCodeController = TextEditingController();
  GlobalKey<FormState> formKey = new GlobalKey<FormState>();
  String _username = '';
  String _password = '';
  String _email = '';
  String _accountname = '';
  String _mobilenumber = '';
  String _companyname = '';
  String _abn = '';
  String _acn = '';
  String _bussinessadd = '';
  String _postcode = '';
  String value = '';
  bool value1 = false;
  String _dropDownTrade;
  String _dropDownAct = '   ACT';
  String _dropDownAccount = '  select';
  String dropDownValue = '';

  List<CheckboxList> CheckboxListItem = [
    CheckboxList(
      title: 'TICK: I am Qulified Trades Person',
      isSelect: false,
    ),
    CheckboxList(
      title: 'TICK: Subscribe to POWAGROUP updated & POWAREWARDS',
      isSelect: false,
    ),
    CheckboxList(
      title: 'TICK: I agree to POWAGROUP Terms and conditions',
      isSelect: false,
    ),
  ];

  List<String> trade = [
    'Plumbing',
    'HAVC',
    'Fire Services',
    'Electrical',
    'Builders or other Trands',
  ];

  List<String> act = ['NSW', 'NT', 'QWD', 'SA', 'VIC', 'WA'];

  List<String> accountType = [
    'C.O.D TRADE ACCOUNT',
    '3o DAY EOM TRADE ACCOUNT'
  ];

  Api api = locator<Api>();

  String get userName => _username;
  set userName(String userName) {
    _username = userName;
    notifyListeners();
  }

  String get dropDownTrade => _dropDownTrade;
  set dropDownTrade(String dropDownTrade) {
    _dropDownTrade = dropDownTrade;
    notifyListeners();
  }

  String get dropDownAct => _dropDownAct;
  set dropDownAct(String dropDownAct) {
    _dropDownAct = dropDownAct;
    notifyListeners();
  }

  String get dropDownAccount => _dropDownAccount;
  set dropDownAccount(String dropDownAccount) {
    _dropDownAccount = dropDownAccount;
    notifyListeners();
  }

  String get password => _password;
  set password(String password) {
    _password = password;
    notifyListeners();
  }

  String get email => _email;
  set Email(String Email) {
    _email = Email;
    notifyListeners();
  }

  String get accountName => _accountname;
  set accountName(String accountName) {
    _accountname = accountName;
    notifyListeners();
  }

  String get mobileNumber => _mobilenumber;
  set mobileNumber(String mobileNumber) {
    _mobilenumber = mobileNumber;
    notifyListeners();
  }

  String get companyName => _companyname;
  set companyName(String companyName) {
    _companyname = companyName;
    notifyListeners();
  }

  String get aBN => _abn;
  set aBN(String aBN) {
    _abn = aBN;
    notifyListeners();
  }

  String get aCN => _acn;
  set aCN(String aCN) {
    _acn = aCN;
    notifyListeners();
  }

  String get bussinessAdd => _bussinessadd;
  set bussinessAdd(String bussinessAdd) {
    _bussinessadd = bussinessAdd;
    notifyListeners();
  }

  String get postCode => _postcode;
  set postCode(String postCode) {
    _postcode = postCode;
    notifyListeners();
  }

  set dropdown(var value) {
    this.value = value;
    notifyListeners();
  }

  // on login buttion clik
  onRegisterButtonClick() {
    if (userNameController.text.isNotEmpty) {
      callSendOtpApi();
    }
  }

  //  send otp api calling
  callSendOtpApi() async {
    // setBusy(true);
    // Map<String, dynamic> request = {};
    // request["country_code"] = countryCode;
    // request["mobile_number"] = int.parse(numberctrl.text);
    // SendOtpResp loginResp = await api.sendOtpApi(request);
    // switch (loginResp.statusCode) {
    //   case Constants.sucessCode:
    //     OtpviewArguments arg =
    //         OtpviewArguments(number: numberctrl.text, countryCode: countryCode);
    //     navigationService.navigateTo(Routes.otpview, arguments: arg);

    //     // SharedPre.setStringValue(SharedPre.PHONE_NUMBER, emailCtrl.text);
    //     // SharedPre.setStringValue(
    //     //  SharedPre.COUNTRY_CODE, "+" + country.phoneCode);
    //     break;
    //   case Constants.wrongError:
    //     //COMMENT
    //     // OtpviewArguments arg =
    //     //     OtpviewArguments(number: numberctrl.text, countryCode: countryCode);
    //     // navigationService.navigateTo(Routes.otpview, arguments: arg);
    //     //  //COMMENT
    //     AppUtil.showToast(loginResp.error ?? '');
    //     // AppUtil.showToast(loginResp.message ?? '');
    //     break;
    //   case Constants.networkErroCode:
    //     AppUtil.showToast(loginResp.error ?? '');
    //     break;
    //   default:
    //     {
    //       if (loginResp.error != null && loginResp.error!.isNotEmpty) {
    //         AppUtil.showToast(loginResp.error ?? '');
    //       } else if (loginResp.message != null &&
    //           loginResp.message!.isNotEmpty) {
    //         AppUtil.showToast(loginResp.message ?? '');
    //       }
    //     }
    //     break;
    // }
    // setBusy(false);
  }
}

class CheckboxList {
  String title;
  bool isSelect = false;

  CheckboxList({this.title, this.isSelect});
}
